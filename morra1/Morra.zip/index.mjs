import { loadStdlib } from '@reach-sh/stdlib';
import * as backend from './build/index.main.mjs';

(async () => {
  const stdlib = await loadStdlib();
  const startingBalance = stdlib.parseCurrency(10);

  const accAlice = await stdlib.newTestAccount(startingBalance);
  const accBob = await stdlib.newTestAccount(startingBalance);

  const ctcAlice = accAlice.deploy(backend);
  const ctcBob = accBob.attach(backend, ctcAlice.getInfo());

  const FINGERS = ['0', '1', '2'];
  const OUTCOME = ['Bob wins', 'Draw', 'Alice wins'];
  const GUESS = ['0', '1', '2', '3', '4'];
  const Player = (Who) => ({
    getFingers: () => {
      const fingers = Math.floor(Math.random() * 3);
      console.log(`${Who} played ${FINGERS[fingers]}`);
      return fingers;
    },
    getGuess: () => {
      const guess= Math.floor(Math.random() * 5) + Math.floor(Math.random() * 5);
      // need a total guess
      console.log(`${Who} played ${GUESS[guess]}`);
      return guess;
    },
    seeOutcome: (outcome) => {
      console.log(`${Who} saw outcome ${OUTCOME[outcome]}`);
    },
  });

  await Promise.all([
    backend.Alice(
      ctcAlice,
      Player('Alice'),
    ),
    backend.Bob(
      ctcBob,
      Player('Bob'),
    ),
  ]);
})();
